Companion web page for the article

Invariant Polydiagonal Subspaces and Constraint Programming

by

John M. Neuberger, Nandor Sieben, James W. Swift
