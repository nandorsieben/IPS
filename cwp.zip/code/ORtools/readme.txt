Requirements: 

1. OR-tools (https://en.wikipedia.org/wiki/OR-Tools)
It can be isntalled with:
pip3 install ortools


Usage:
python3 polydiagonal.py
python3 synchrony.py
The code reads a matrix from the file M.txt and prints the coloring vectors to standard output.
