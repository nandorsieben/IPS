Requirements:

1. DOcplex (https://en.wikipedia.org/wiki/CPLEX)
It can be isntalled with:
pip3 install docplex

2. cpoptimizer
It is part of the IBM ILOG Cplex optimization software. It has a free academic licence.


Usage:
python3 polydiagonal.py
python3 synchrony.py
The code reads a matrix from the file M.txt and prints the coloring vectors to standard output.
