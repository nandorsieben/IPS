Requirements: 

1. z3-solver (https://en.wikipedia.org/wiki/Z3_Theorem_Prover)
It can be isntalled with:
pip3 install z3-solver


Usage:
python3 polydiagonal.py
python3 synchrony.py
The code reads a matrix from the file M.txt and prints the coloring vectors to standard output.
