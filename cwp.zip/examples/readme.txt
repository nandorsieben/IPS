Buckyball: Adjacency matrix of the Buckyball graph (Example 6.2)
BuckyballQuotient: Adjacency matrix of a quotient digraph of the Buckyball graph (Example 6.2)
Cycle50: Laplacian of the cycle graph with 50 vertices (Table 5.1)
Path100: Laplacian of the path graph with 100 vertices
Petersen: Adjacency matrix of the Petersen graph (Example 6.1)
basic: basic example (Example 4.4)

File types:
M.txt: matrix
graph.pdf: graph
output.txt: coloring vectors of M-invariant polydiagonal subspaces
poset.pdf: lattice of M-invariant polydiagonal subspaces
posetOrbit.pdf: poset of orbit classes of M-invariant polydiagonal subspaces
